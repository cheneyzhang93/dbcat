package cc.dbcat.dev.ui.menu;

/**
 * 菜单DSL解释器,
 * 一个MenuBar为单位定义DSL,并且对文件进行版本管理,格式为 MenuDSL_vx.x.x, _v 之后为具体版本号
 */
public class MenuDSLInterpreter {

}
