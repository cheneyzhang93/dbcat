package cc.dbcat.dev.ui.menu;

public class test {
}
